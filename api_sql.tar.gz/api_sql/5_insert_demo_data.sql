INSERT INTO `Session` (`ID`, `Name`, `TimeOfEvent`, `Description`) VALUES (NULL, 'session 1', '2016-10-03 00:00:00', ''), (NULL, 'session 2', '2016-10-11 09:00:00', '');

INSERT INTO `User` (`ID`, `Name`, `Email`, `Update`) VALUES
(1, 'Кирилл', 'kirill@email.su', '2016-10-21 23:27:21'),
(2, 'Мифодий', 'greg@radiorecord.ru', '2016-10-21 23:27:21'),
(3, 'Ostap', 'ostap@email.su', '2016-10-21 23:28:39'),
(4, '121Klimm', 'klimmens@mail.ru', '2016-10-21 23:28:39'),
(5, 'Трифон', 'trifon@kdk.ru', '2016-10-22 03:15:47');

INSERT INTO `Spot` (`ID`, `SessionId`, `UserId`, `Position`, `Booked`, `Confirmed`) VALUES
(6, 1, NULL, NULL, NULL, NULL),
(7, 1, NULL, NULL, NULL, NULL),
(8, 1, NULL, NULL, NULL, NULL),
(9, 2, NULL, NULL, NULL, NULL);
