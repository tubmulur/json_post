-- ALTER NEWS
ALTER TABLE `News` ADD  `non_unique_hash` char(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'Не уникальная';
ALTER TABLE `News` ADD  `active` tinyint(1) DEFAULT '0';
ALTER TABLE `News` ADD  `dateCreate` timestamp NULL DEFAULT CURRENT_TIMESTAMP;
UPDATE `News` SET `active`=1;
