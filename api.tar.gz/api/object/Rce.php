<?php
class Rce{
	public function __construct()
		{
		}
}
?>