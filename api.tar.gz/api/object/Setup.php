<?php
class Setup{
	public function __construct(){
		$this->read_models();
	}
	private function read_models(){
		
	}
}
?>